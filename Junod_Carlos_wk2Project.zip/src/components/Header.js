import React from 'react';

const Header = (props) => {
    return (
        <header id="mainHeader">
            <h1>My Money App</h1>
        </header>
    );
  }


export default Header;
