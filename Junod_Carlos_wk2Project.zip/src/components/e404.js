import React from 'react';

const e404 = (props) => {
    return (
        <div>
            <h1>404</h1>
        </div>
    );
  }


export default e404;
