import React, { Component } from 'react';

class Aside extends Component {
  render() {
    return (
      <aside>
        <ul>
            <li>List on the aside</li>
            <li>List on the aside</li>
            <li>List on the aside</li>
            <li>List on the aside</li>
        </ul>
      </aside>
    );
  }
}

export default Aside;
