import React, { Component } from 'react';

class StatusBalance extends Component {
  render() {
      // <button>Add purchase</button>
    return (
        <div id="statusBalance">
            <div id="figure">
                <span>$1,000.00</span>
            </div>
            <div id="add">

            </div>
        </div>
    );
  }
}

export default StatusBalance;
