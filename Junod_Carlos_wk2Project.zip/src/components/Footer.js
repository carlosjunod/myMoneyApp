import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
      <footer>
      <p>made by @carlosjunod for Full Sail University </p>
      </footer>
    );
  }
}

export default Footer;
